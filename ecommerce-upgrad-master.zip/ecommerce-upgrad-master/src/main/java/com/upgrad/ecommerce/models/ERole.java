package com.upgrad.ecommerce.models;

public enum ERole {
    USER,
    ADMIN
}
