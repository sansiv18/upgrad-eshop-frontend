package com.upgrad.ecommerce.utils;


import lombok.Data;

@Data
public class FieldError {

    private String field;
    private String errorCode;

}
